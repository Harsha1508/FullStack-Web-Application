import axios from "axios";

export const add1 = async ({
  buss_code,
  cust_num,
  clear_date,
  buss_year,
  doc_id,
  pos_date,
  d_date,
  due_date,
  invoice,
  doc_type,
  pos_id,
  total,
  bc_date,
  cpt,
  invoice_id,
}) => {
  let data =
    "buss_code=" +
    buss_code +
    "&cust_num=" +
    cust_num +
    "&clear_date=" +
    clear_date +
    "&buss_year=" +
    buss_year +
    "&doc_id=" +
    doc_id +
    "&pos_date=" +
    pos_date +
    "&d_date=" +
    d_date +
    "&due_date=" +
    due_date +
    "&invoice=" +
    invoice +
    "&doc_type=" +
    doc_type +
    "&pos_id=" +
    pos_id +
    "&total=" +
    total +
    "&bc_date=" +
    bc_date +
    "&cpt=" +
    cpt +
    "&invoice_id=" +
    invoice_id;

  let response = await axios.get(
    "http://localhost:8082/HRC21137W-back_end/Add?" + data
  );
  alert("Added Successfully");
  return response.data;
};

export const edit1 = async ({ sl_no, invoice, cpt }) => {
  let data = "sl_no=" + sl_no + "&invoice=" + invoice + "&cpt=" + cpt;

  let response1 = await axios.get(
    "http://localhost:8082/HRC21137W-back_end/Edit?" + data
  );
  alert("Edited Successfully");
  return response1.data;
};

export const delete1 = async ({ sl_no }) => {
  let data = "sl_no=" + sl_no;

  let response1 = await axios.get(
    "http://localhost:8082/HRC21137W-back_end/Delete?" + data
  );
  alert("Deleted Successfully");
  return response1.data;
};

export const advancesearch = async ({
  doc_id,
  invoice_id,
  cust_num,
  buss_year,
}) => {
  let data =
    "doc_id=" +
    doc_id +
    "&invoice_id=" +
    invoice_id +
    "&cust_number=" +
    cust_num +
    "&buisness_year=" +
    buss_year;

  let response1 = await axios.get(
    "http://localhost:8082/HRC21137W-back_end/AdvanceSearch?" + data
  );
  return response1.data;
};

export const simplesearch = async ({ cust_num }) => {
  let data = "&cust_number=" + cust_num;
  let response1 = await axios.get(
    "http://localhost:8082/HRC21137W-back_end/Simplesearch?" + data
  );
  return response1.data;
};

export const analyPie = async ({
  clear_date_start,
  due_date_start,
  clear_date_end,
  due_date_end,
  baseline_start,
  baseline_end,
  invoice_Currency,
}) => {
  let data =
    "clear_date_start=" +
    clear_date_start +
    "&due_date_start=" +
    due_date_start +
    "&clear_date_end=" +
    clear_date_end +
    "&due_date_end=" +
    due_date_end +
    "&baseline_start=" +
    baseline_start +
    "&baseline_end=" +
    baseline_end +
    "&invoice_Currency=" +
    invoice_Currency;

  let response1 = await axios.get(
    "http://localhost:8082/HRC21137W-back_end/AnalyticsPie?" + data
  );
  return response1.data;
};

export const analyBar = async ({
  clear_date_start,
  due_date_start,
  clear_date_end,
  due_date_end,
  baseline_start,
  baseline_end,
  invoice_Currency,
}) => {
  let data =
    "clear_date_start=" +
    clear_date_start +
    "&due_date_start=" +
    due_date_start +
    "&clear_date_end=" +
    clear_date_end +
    "&due_date_end=" +
    due_date_end +
    "&baseline_start=" +
    baseline_start +
    "&baseline_end=" +
    baseline_end +
    "&invoice_Currency=" +
    invoice_Currency;

  let response1 = await axios.get(
    "http://localhost:8082/HRC21137W-back_end/AnalyticsBar?" + data
  );
  return response1.data;
};
