import React, { useState } from "react";
import "./css/Analytics.css";
import { analyPie, analyBar } from "./data";
import BarGraph from "./BarGraph";

const Analytics = ({
  closeAnalyticsbutton,
  setshowBar,
  showBar,
  setshowBar1,
  showBar1,
}) => {
  const [Analytics1, setAnalytics1] = useState({
    clear_date_start: "",
    due_date_start: "",
    clear_date_end: "",
    due_date_end: "",
    baseline_start: "",
    baseline_end: "",
    invoice_Currency: "",
  });
  const {
    clear_date_start,
    due_date_start,
    clear_date_end,
    due_date_end,
    baseline_start,
    baseline_end,
    invoice_Currency,
  } = Analytics1;

  const submitHandler = async (e) => {
    e.preventDefault();

    analyBar(Analytics1).then((data) => setshowBar1(data));

    analyPie(Analytics1).then((data) => setshowBar(data));
    if (showBar) {
      setAnalytics1({
        clear_date_start: "",
        due_date_start: "",
        clear_date_end: "",
        due_date_end: "",
        baseline_start: "",
        baseline_end: "",
        invoice_Currency: "",
      });
      setshowBar(true);
      setshowBar1(true);
    }
  };

  const changeHandler = (e) => {
    setAnalytics1({ ...Analytics1, [e.target.name]: e.target.value });
  };

  return (
    <>
      <form>
        <div className="holder2">
          <div className="analyticsbackground">
            <span>
              <h1 className="addtitle">Analytics View</h1>
            </span>
            <div className="analyticsinputfields">
              <div className="adv_setone">
                <div>
                  <label id="a">Clear Date</label>
                  <label id="b">Due Date</label>
                </div>
                <input
                  id="clear_date_start"
                  type="date"
                  name="clear_date_start"
                  value={clear_date_start}
                  onChange={(e) => changeHandler(e)}
                />
                <input
                  id="due_date_start"
                  type="date"
                  name="due_date_start"
                  value={due_date_start}
                  onChange={(e) => changeHandler(e)}
                />
                <br />
                <input
                  id="clear_date_end"
                  type="date"
                  name="clear_date_end"
                  value={clear_date_end}
                  onChange={(e) => changeHandler(e)}
                />
                <input
                  id="due_date_end"
                  type="date"
                  name="due_date_end"
                  value={due_date_end}
                  onChange={(e) => changeHandler(e)}
                />
                <br />
                <br />
                <div>
                  <label id="c">Baseline Create Date</label>
                  <label id="d">Invoice Currency</label>
                </div>
                <input
                  id="baseline_start"
                  type="date"
                  name="baseline_start"
                  value={baseline_start}
                  onChange={(e) => changeHandler(e)}
                />

                <input
                  id="invoice_Currency"
                  type="text"
                  placeholder="Invoice Currency"
                  name="invoice_Currency"
                  value={invoice_Currency}
                  onChange={(e) => changeHandler(e)}
                />
                <br />
                <input
                  id="baseline_end"
                  type="date"
                  name="baseline_end"
                  value={baseline_end}
                  onChange={(e) => changeHandler(e)}
                />
              </div>
              <div>
                <input
                  type="submit"
                  value={"Submit"}
                  class="analyticbutton"
                  onClick={(e) => submitHandler(e)}
                ></input>

                <button
                  class="cancel1"
                  onClick={() => closeAnalyticsbutton(false)}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
        {showBar && showBar1 && (
          <BarGraph
            closeBarGraph={setshowBar}
            showBar={showBar}
            showBar1={showBar1}
          />
        )}
      </form>
    </>
  );
};

export default Analytics;
