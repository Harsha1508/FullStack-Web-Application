import React from "react";
import { edit1 } from "./data.js";
import { useState } from "react";
import "./css/Editbutton.css";
import { TextField } from "@material-ui/core";

function Editbutton(props) {
  console.log(props);
  const { closeEditbutton, currentrowid } = props;
  const [editbutton1, seteditbutton1] = useState({
    sl_no: currentrowid,
    invoice: "",
    cpt: "",
  });
  const { invoice, cpt } = editbutton1;

  const changeHandler = (e) => {
    seteditbutton1({ ...editbutton1, [e.target.name]: e.target.value });
  };
  const submitHandler = async (e) => {
    e.preventDefault();
    if (currentrowid.length > 1) {
      alert("Sorry! You cannot Edit more than one row at a time.");
    } else {
      let response = edit1(editbutton1);
      if (response) {
        seteditbutton1({
          invoice: "",

          cpt: "",
        });
      }
    }
  };

  return (
    <>
      <form>
        <div className="holder">
          <div className="editpopupbackground">
            <span>
              <h1 className="addtitle">EDIT</h1>
            </span>
            <div className="editinputfields">
              <div className="editsetone">
                <TextField
                  id="invoice"
                  type="text"
                  value={invoice}
                  name="invoice"
                  onChange={(e) => changeHandler(e)}
                  label="Invoice Currency"
                  variant="filled"
                  size="small"
                  required
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="cpt"
                  type="text"
                  name="cpt"
                  value={cpt}
                  onChange={(e) => changeHandler(e)}
                  label="Customer Payment Terms"
                  variant="filled"
                  size="small"
                  required
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
              </div>
            </div>
            <br />

            <div class="editbuttons">
              <div>
                <input
                  type="submit"
                  value={"Edit"}
                  className="editbutton1"
                  onClick={(e) => submitHandler(e)}
                ></input>
                <button
                  className="cancelbutton"
                  onClick={() => closeEditbutton(false)}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </>
  );
}

export default Editbutton;
