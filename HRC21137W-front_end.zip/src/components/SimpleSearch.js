import React from "react";
import { useState } from "react";

import { simplesearch } from "./data.js";

const Simplesearch = (props) => {
  const { setTabledata } = props;
  const [Simplesearch1, setSimplesearch1] = useState({
    cust_num: "",
  });
  const { cust_num } = Simplesearch1;

  const changeHandler = (e) => {
    setSimplesearch1({ ...Simplesearch1, [e.target.name]: e.target.value });
  };

  const submitHandler = async (e) => {
    e.preventDefault();

    simplesearch(Simplesearch1).then((data) => setTabledata(data));
  };

  return (
    <>
      <input
        type="number"
        placeholder="Search Customer ID"
        value={cust_num}
        name="cust_num"
        onChange={(e) => changeHandler(e)}
      />
      <button type="submit" onClick={(e) => submitHandler(e)}>
        Search
      </button>
    </>
  );
};
export default Simplesearch;
