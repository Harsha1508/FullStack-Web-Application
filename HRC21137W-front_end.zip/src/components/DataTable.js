import React, { useState, useEffect } from "react";
import { DataGrid } from "@material-ui/data-grid";
import "./css/DataTable.css";

import "@mui/material/styles";

const columns = [
  { field: "sl_no", headerName: "Sl No", width: 115 },
  { field: "bCode", headerName: "Bussiness Code", width: 180 },
  { field: "custNumber", headerName: "Customer Number", width: 200 },
  { field: "clear_date", headerName: "Clear Date", width: 150 },
  { field: "bussinessyear", headerName: "Bussiness year", width: 180 },
  { field: "docid", headerName: "Doc ID", width: 120 },
  { field: "postingdate", headerName: "Posting Date", width: 165 },
  {
    field: "documentcreatedate",
    headerName: "Document Create Date",
    width: 200,
  },
  { field: "due_in_date", headerName: "Due in Date", width: 160 },
  { field: "invoice_currency", headerName: "Invoice Currency", width: 190 },
  { field: "document_type", headerName: "Document Type", width: 180 },
  { field: "posting_id", headerName: "Posting ID", width: 155 },

  { field: "total_open_amount", headerName: "Total open amount", width: 200 },
  {
    field: "baseline_create_date",
    headerName: "Baseline Create date",
    width: 200,
  },
  { field: "cust_payment_terms", headerName: "Cust Payment Terms", width: 200 },
  { field: "invoice_id", headerName: "Invoice ID", width: 200 },
];

const DataTable = ({
  setcurrentrowid,
  setSelectedRows,
  tableData,
  setTableData,
}) => {
  const [tablestate, settablestate] = useState([]);

  const [pageSize, setPageSize] = React.useState(10);

  useEffect(() => {
    fetch("http://localhost:8082/HRC21137W-back_end/Fetch")
      .then((data) => data.json())
      .then((data) => settablestate(data));
  }, []);

  useEffect(() => {
    settablestate(tableData);
  }, [tableData]);

  return (
    <div
      style={{
        height: 472,
        width: "100%",
        backgroundColor: "#69808d79",
      }}
    >
      <DataGrid
        sx={{
          "& MuiTablePagination-root": {
            textOverflow: "clip",
            whiteSpace: "break-spaces",
            color: "white",
            lineHeight: 3,
          },
        }}
        rows={tablestate}
        classes={{ root: "datagrid", body2: "datagrid" }}
        getRowId={(row) => row.sl_no}
        columns={columns}
        pageSize={pageSize}
        onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
        rowsPerPageOptions={[10, 20, 30, 40, 50]}
        rowHeight={34.5}
        pagination={true}
        {...tableData}
        checkboxSelection
        onSelectionModelChange={(ids) => {
          setcurrentrowid(ids);
          setSelectedRows(ids);
          console.log(ids);
          console.log(ids[0]);
        }}
      />
    </div>
  );
};

export default DataTable;
