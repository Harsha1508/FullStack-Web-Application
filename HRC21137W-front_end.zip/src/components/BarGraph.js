import React from "react";
import "./css/BarGraph.css";
import "./Analytics";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
} from "chart.js";
import { Pie, Bar } from "react-chartjs-2";

ChartJS.register(
  ArcElement,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale
);

function BarGraph({ closeBarGraph, showBar, showBar1 }) {
  //Piechart
  var piedata = {
    labels: showBar?.map((x) => x.invoice_currency),
    datasets: [
      {
        data: showBar?.map((x) => x.Total),
        backgroundColor: ["rgba(255, 99, 132, 0.5)", "rgba(75, 192, 192, 0.5)"],
        borderColor: ["rgba(255, 255, 255, 1)"],
        borderWidth: 2,
      },
    ],
  };

  var pieoptions = {
    responsive: true,
    aspectRatio: 5,
    maintainAspectRatio: true,
    scales: {},
  };

  var baroptions = {
    responsive: true,
    aspectRatio: 5,
    maintainAspectRatio: true,
    scales: {
      x: {
        ticks: {
          color: "white",
        },
      },
      y: {
        ticks: {
          color: "white",
        },
      },
    },
  };

  //Bargraph

  var bardata = {
    labels: showBar1?.map((x) => x.businessCode),
    datasets: [
      {
        data: showBar1?.map((x) => x.totalCustomers),
        label: "Total Number of Customers",
        borderColor: "#3333ff",
        backgroundColor: "rgba(255, 159, 64, 1)",
        fill: true,
      },
      {
        data: showBar1?.map((x) => x.totalAmount),
        label: "Total Open Amount",
        borderColor: "#ff3333",
        backgroundColor: "rgba(153, 102, 255, 1)",
        fill: true,
      },
    ],
  };

  return (
    <>
      <div className="chart">
        <header>
          <span>
            <button className="close1" onClick={() => closeBarGraph(false)}>
              X
            </button>
          </span>
        </header>
        <body>
          <Pie data={piedata} height={400} options={pieoptions} />
          <br />

          <Bar data={bardata} height={400} options={baroptions} />
        </body>
      </div>
    </>
  );
}
export default BarGraph;
