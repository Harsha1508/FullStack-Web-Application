import React from "react";
import { useState } from "react";
import "./css/AdvanceSearch.css";
import { advancesearch } from "./data.js";
import { TextField } from "@material-ui/core";

const AdvanceSearch = (props) => {
  console.log(props);
  const { closesearchbutton, setTabledata } = props;
  const [Searchbutton1, setSearchbutton1] = useState({
    doc_id: "",
    invoice_id: "",
    cust_num: "",
    buss_year: "",
  });
  const { doc_id, invoice_id, cust_num, buss_year } = Searchbutton1;

  const changeHandler = (e) => {
    setSearchbutton1({ ...Searchbutton1, [e.target.name]: e.target.value });
  };

  const submitHandler = async (e) => {
    e.preventDefault();

    advancesearch(Searchbutton1).then((data) => setTabledata(data));
  };

  return (
    <>
      <form>
        <div className="holder1">
          <div className="advsearchbackground">
            <span>
              <h1 className="addtitle">Advance Search</h1>
            </span>
            <div className="searchinputfields">
              <div className="adv_setone">
                <TextField
                  id="doc_id1"
                  type="text"
                  name="doc_id"
                  value={doc_id}
                  onChange={(e) => changeHandler(e)}
                  label="Document ID"
                  variant="filled"
                  size="small"
                  required
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <span id="invoicebussiness">
                  <TextField
                    id="invoice_id1"
                    type="text"
                    name="invoice_id"
                    value={invoice_id}
                    onChange={(e) => changeHandler(e)}
                    label="Invoice ID"
                    variant="filled"
                    size="small"
                    required
                    defaultValue="Normal"
                    InputLabelProps={{
                      style: { color: "Black" },
                    }}
                  />
                </span>
              </div>

              <div className="adv_setone">
                <TextField
                  id="cust_num1"
                  type="number"
                  name="cust_num"
                  value={cust_num}
                  onChange={(e) => changeHandler(e)}
                  label="Customer Number"
                  variant="filled"
                  size="small"
                  required
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <span id="invoicebussiness">
                  <TextField
                    id="buss_year1"
                    type="text"
                    name="buss_year"
                    value={buss_year}
                    onChange={(e) => changeHandler(e)}
                    label="Bussiness Year"
                    variant="filled"
                    size="small"
                    required
                    defaultValue="Normal"
                    InputLabelProps={{
                      style: { color: "Black" },
                    }}
                  />
                </span>
              </div>
            </div>
            <br />

            <div className="searchbuttons">
              <div>
                <input
                  type="submit"
                  value={"Search"}
                  className="searchbutton"
                  onClick={(e) => submitHandler(e)}
                ></input>

                <button
                  className="cancelbutton1"
                  onClick={() => closesearchbutton(false)}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </>
  );
};

export default AdvanceSearch;
