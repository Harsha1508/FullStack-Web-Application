import React from "react";
import "./css/Deletebutton.css";
import { useState } from "react";
import { delete1 } from "./data.js";

function Deletebutton(props) {
  console.log(props);
  // const { closeDeletebutton, currentrowid } = props;
  const { closeDeletebutton, selectedRows } = props;
  const [deletebutton1, setdeletebutton1] = useState({ sl_no: selectedRows });
  const { sl_no } = deletebutton1;
  console.log(selectedRows);

  const submitHandler = async (e) => {
    e.preventDefault();
    let response = delete1(deletebutton1);
  };

  return (
    <form>
      <div className="holder">
        <div className="deletepopupbackground">
          <span>
            <h1 className="addtitle">DELETE</h1>
          </span>
          <div className="warning">
            <h2>Are you sure you want to delete these Record[s]?</h2>
          </div>
          <br />
          <div class="deletebuttons">
            <span>
              <input
                type="submit"
                value={"Delete"}
                class="deletebutton1"
                onClick={(e) => submitHandler(e)}
              ></input>

              <button
                onClick={() => closeDeletebutton(false)}
                class="cancelbutton2"
              >
                Cancel
              </button>
            </span>
          </div>
        </div>
      </div>
    </form>
  );
}

export default Deletebutton;
