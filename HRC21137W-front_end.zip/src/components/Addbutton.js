import React, { useState } from "react";
import "./css/Addbutton.css";
import { add1 } from "./data.js";
import { TextField } from "@material-ui/core";

const Addbutton = ({ closeAddbutton }) => {
  const [Addbutton1, setAddbutton1] = useState({
    buss_code: "",
    cust_num: "",
    clear_date: "",
    buss_year: "",
    doc_id: "",
    pos_date: "",
    d_date: "",
    due_date: "",
    invoice: "",
    doc_type: "",
    pos_id: "",
    total: "",
    bc_date: "",
    cpt: "",
    invoice_id: "",
  });

  const {
    buss_code,
    cust_num,
    clear_date,
    buss_year,
    doc_id,
    pos_date,
    d_date,
    due_date,
    invoice,
    doc_type,
    pos_id,
    total,
    bc_date,
    cpt,
    invoice_id,
  } = Addbutton1;
  const submitHandler = async (e) => {
    e.preventDefault();

    let response = add1(Addbutton1);

    if (response) {
      setAddbutton1({
        buss_code: "",
        cust_num: "",
        clear_date: "",
        buss_year: "",
        doc_id: "",
        pos_date: "",
        d_date: "",
        due_date: "",
        invoice: "",
        doc_type: "",
        pos_id: "",
        total: "",
        bc_date: "",
        cpt: "",
        invoice_id: "",
      });
    }
  };

  const changeHandler = (e) => {
    setAddbutton1({ ...Addbutton1, [e.target.name]: e.target.value });
  };

  return (
    <>
      <form>
        <div className="holder">
          <div className="addpopupbackground">
            <span>
              <h1 className="addtitle">ADD</h1>
            </span>
            <div className="inputfields">
              <div className="addsetone">
                <TextField
                  id="buss_code"
                  type="text"
                  name="buss_code"
                  value={buss_code}
                  onChange={(e) => changeHandler(e)}
                  label="Bussiness Code"
                  variant="filled"
                  size="small"
                  required
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="cust_num"
                  type="Number"
                  name="cust_num"
                  value={cust_num}
                  onChange={(e) => changeHandler(e)}
                  label="Customer Number"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  required
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="clear_date"
                  type="date"
                  name="clear_date"
                  value={clear_date}
                  onChange={(e) => changeHandler(e)}
                  label="Clear Date"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    shrink: true,
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="buss_year"
                  name="buss_year"
                  type="Number"
                  value={buss_year}
                  onChange={(e) => changeHandler(e)}
                  label="Bussiness Year"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
              </div>
              <br />

              <div>
                <TextField
                  id="doc_id"
                  type="Number"
                  value={doc_id}
                  name="doc_id"
                  onChange={(e) => changeHandler(e)}
                  label="Document ID"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="pos_date"
                  type="date"
                  name="pos_date"
                  value={pos_date}
                  onChange={(e) => changeHandler(e)}
                  label="Posting Date"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    shrink: true,
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="d_date"
                  type="date"
                  value={d_date}
                  name="d_date"
                  onChange={(e) => changeHandler(e)}
                  label="Document Create Date"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    shrink: true,
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="due_date"
                  type="date"
                  value={due_date}
                  name="due_date"
                  onChange={(e) => changeHandler(e)}
                  label="Due Date"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    shrink: true,
                    style: { color: "Black" },
                  }}
                />
              </div>
              <br />

              <div>
                <TextField
                  id="invoice"
                  type="text"
                  value={invoice}
                  name="invoice"
                  onChange={(e) => changeHandler(e)}
                  label="Invoice Currency"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="doc_type"
                  type="text"
                  value={doc_type}
                  name="doc_type"
                  onChange={(e) => changeHandler(e)}
                  label="Document Type"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="pos_id"
                  type="Number"
                  name="pos_id"
                  value={pos_id}
                  onChange={(e) => changeHandler(e)}
                  label="Posting ID"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="total"
                  type="Number"
                  name="total"
                  value={total}
                  onChange={(e) => changeHandler(e)}
                  label="Total Open Amount"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
              </div>

              <br />

              <div>
                <TextField
                  id="bc_date"
                  type="date"
                  value={bc_date}
                  name="bc_date"
                  onChange={(e) => changeHandler(e)}
                  label="Bussiness Create Date"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    shrink: true,
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="cpt"
                  type="text"
                  name="cpt"
                  value={cpt}
                  onChange={(e) => changeHandler(e)}
                  label="Customer Payment Terms"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <TextField
                  id="invoice_id"
                  type="Number"
                  name="invoice_id"
                  value={invoice_id}
                  onChange={(e) => changeHandler(e)}
                  label="Invoice ID"
                  variant="filled"
                  size="small"
                  defaultValue="Normal"
                  InputLabelProps={{
                    style: { color: "Black" },
                  }}
                />
                <span>
                  <input
                    type="submit"
                    value={"Add"}
                    className="Add"
                    onClick={(e) => submitHandler(e)}
                  ></input>
                  <input
                    type="cancel"
                    className="Cancel"
                    value={"Cancel"}
                    onClick={() => closeAddbutton(false)}
                  />
                </span>
              </div>
            </div>
          </div>
        </div>
      </form>
    </>
  );
};

export default Addbutton;
