import React from "react";
import "./components/css/homepage.css";
import abc from "./images/abc.png";
import hrclogo from "./images/logo.png";
import Addbutton from "./components/Addbutton";
import { useState } from "react";
import Editbutton from "./components/Editbutton";
import Deletebutton from "./components/Deletebutton";
import AdvanceSearch from "./components/AdvanceSearch";
import Simplesearch from "./components/SimpleSearch";
import Analytics from "./components/Analytics";

const Home = ({
  currentrowid,
  selectedRows,
  setTabledata,
  setshowBar,
  showBar,
  showBar1,
  setshowBar1,
}) => {
  const [openAddButton, setAddButton] = useState(false);
  const [openEditButton, setEditButton] = useState(false);
  const [openDeleteButton, setDeleteButton] = useState(false);
  const [opensearchButton, setsearchButton] = useState(false);
  const [openAnalyticsButton, setAnalyticsButton] = useState(false);

  function refreshPage() {
    window.location.reload(false);
  }

  return (
    <>
      <div>
        <meta charSet="utf-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <title>HRC_FINAL</title>
        <meta name="description" content="" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="/components/css/homepage.css" />
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
        />
      </div>

      <div>
        <header id="header">
          <img className="abclogo" src={abc} alt="abclogo" />
          <span>
            <img className="hrclogo" src={hrclogo} alt="HRC logo" />
          </span>
        </header>
        <div>
          <div id="content">
            <span className="btn-group">
              <button type="button" className="predictbutton">
                PREDICT
              </button>
              <button
                type="button"
                className="analyticsbutton"
                onClick={() => {
                  setAnalyticsButton(true);
                }}
              >
                ANALYTICS VIEW
              </button>
              <button
                type="button"
                className="advancebutton"
                onClick={() => {
                  setsearchButton(true);
                }}
              >
                ADVANCE SEARCH
              </button>
              <button
                type="button"
                className="refresh-button"
                onClick={refreshPage}
              >
                <i className="fa fa-refresh"></i>
              </button>
              {/* fa fa-refresh fa-spin */}
              <span id="SimpleSearch">
                <Simplesearch setTabledata={setTabledata} />
              </span>
              <div className="btn-group1">
                <button
                  type="button"
                  className="deletebutton"
                  onClick={() => {
                    setDeleteButton(true);
                  }}
                >
                  DELETE
                </button>
                <button
                  type="button"
                  className="editButton"
                  onClick={() => {
                    setEditButton(true);
                  }}
                >
                  EDIT
                </button>
                <button
                  type="button"
                  className="addButton"
                  onClick={() => {
                    setAddButton(true);
                  }}
                >
                  ADD
                </button>
                {openEditButton && (
                  <Editbutton
                    closeEditbutton={setEditButton}
                    currentrowid={currentrowid}
                  />
                )}{" "}
                {openDeleteButton && (
                  <Deletebutton
                    closeDeletebutton={setDeleteButton}
                    selectedRows={selectedRows}
                  />
                )}
                {openAddButton && <Addbutton closeAddbutton={setAddButton} />}
                {opensearchButton && (
                  <AdvanceSearch
                    closesearchbutton={setsearchButton}
                    setTabledata={setTabledata}
                  />
                )}
                {openAnalyticsButton && (
                  <Analytics
                    closeAnalyticsbutton={setAnalyticsButton}
                    setshowBar={setshowBar}
                    showBar={showBar}
                    showBar1={showBar1}
                    setshowBar1={setshowBar1}
                  />
                )}
              </div>
            </span>
          </div>
        </div>
      </div>
      <div></div>
    </>
  );
};

export default Home;
