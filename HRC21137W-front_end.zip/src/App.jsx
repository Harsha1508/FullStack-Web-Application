import React, { useState } from "react";
import Home from "./Home";
import "./components/css/homepage.css";

import DataTable from "./components/DataTable";

function App() {
  const [currentrowid, setcurrentrowid] = useState(null);
  const [selectedRows, setSelectedRows] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [showBar, setshowBar] = useState(false);
  const [showBar1, setshowBar1] = useState(false);

  return (
    <>
      <div className="Home">
        <Home
          currentrowid={currentrowid}
          selectedRows={selectedRows}
          setTabledata={setTableData}
          setshowBar={setshowBar}
          showBar={showBar}
          showBar1={showBar1}
          setshowBar1={setshowBar1}
        />
      </div>
      <div>
        <DataTable
          setcurrentrowid={setcurrentrowid}
          setSelectedRows={setSelectedRows}
          setTableData={setTableData}
          tableData={tableData}
        />
      </div>
      <p className="Footer">
        <a
          className="link"
          href="https://www.highradius.com/privacy-policy/"
          target="_blank"
        >
          Privacy Policy
        </a>
        <span>
          {" "}
          | &#9426; 2022 HighRadius Corporation. All rights reserved.
        </span>
      </p>
    </>
  );
}

export default App;
