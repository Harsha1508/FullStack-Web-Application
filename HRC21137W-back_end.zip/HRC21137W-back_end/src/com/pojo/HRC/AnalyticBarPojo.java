package com.pojo.HRC;

public class AnalyticBarPojo {
	private String businessCode;
	private String totalCustomers;
	private String totalAmount;
	public String getBusinessCode() {
		return businessCode;
	}
	public void setBusinessCode(String businessCode) {
		this.businessCode = businessCode;
	}
	public String getTotalCustomers() {
		return totalCustomers;
	}
	public void setTotalCustomers(String totalCustomers) {
		this.totalCustomers = totalCustomers;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	

}
