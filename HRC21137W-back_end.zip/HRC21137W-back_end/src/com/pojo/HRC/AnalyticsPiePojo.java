package com.pojo.HRC;

public class AnalyticsPiePojo {
	private String invoice_currency;
	private String Total;
	
	
	public String getInvoice_currency() {
		return invoice_currency;
	}
	public void setInvoice_currency(String invoice_currency) {
		this.invoice_currency = invoice_currency;
	}
	public String getTotal() {
		return Total;
	}
	public void setTotal(String total) {
		Total = total;
	}
	
	
	
	

}
