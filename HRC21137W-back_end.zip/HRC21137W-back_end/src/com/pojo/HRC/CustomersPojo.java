package com.pojo.HRC;

public class CustomersPojo {
	
private int sl_no;
private String bCode;
private String clear_date;
private  String bussinessyear;
private String docid;
private String postingdate;
private String documentcreatedate;
private String documentcreatedate1;
private String due_in_date;
private String  invoice_currency;
private String  document_type;
private String  posting_id;
private String area_business;
private String  total_open_amount;
private String baseline_create_date;;
private String cust_payment_terms;
private String invoice_id;
private String  isOpen;
private String  predicted;
private String is_deleted;

	
//Foreign Key Columns
private String custNumber;
private String bussiness_name;
private String name_customer;

public int getSl_no() {
	return sl_no;
}
public void setSl_no(int sl_no) {
	this.sl_no = sl_no;
}
public String getbCode() {
	return bCode;
}
public void setbCode(String l) {
	this.bCode = l;
}
public String getClear_date() {
	return clear_date;
}
public void setClear_date(String clear_date) {
	this.clear_date = clear_date;
}
public String getBussinessyear() {
	return bussinessyear;
}
public void setBussinessyear(String bussinessyear) {
	this.bussinessyear = bussinessyear;
}
public String getDocid() {
	return docid;
}
public void setDocid(String docid) {
	this.docid = docid;
}
public String getPostingdate() {
	return postingdate;
}
public void setPostingdate(String postingdate) {
	this.postingdate = postingdate;
}
public String getDocumentcreatedate() {
	return documentcreatedate;
}
public void setDocumentcreatedate(String documentcreatedate) {
	this.documentcreatedate = documentcreatedate;
}
public String getDocumentcreatedate1() {
	return documentcreatedate1;
}
public void setDocumentcreatedate1(String documentcreatedate1) {
	this.documentcreatedate1 = documentcreatedate1;
}
public String getDue_in_date() {
	return due_in_date;
}
public void setDue_in_date(String due_in_date) {
	this.due_in_date = due_in_date;
}
public String getInvoice_currency() {
	return invoice_currency;
}
public void setInvoice_currency(String invoice_currency) {
	this.invoice_currency = invoice_currency;
}
public String getDocument_type() {
	return document_type;
}
public void setDocument_type(String document_type) {
	this.document_type = document_type;
}
public String getPosting_id() {
	return posting_id;
}
public void setPosting_id(String posting_id) {
	this.posting_id = posting_id;
}
public String getArea_business() {
	return area_business;
}
public void setArea_business(String area_business) {
	this.area_business = area_business;
}
public String getTotal_open_amount() {
	return total_open_amount;
}
public void setTotal_open_amount(String total_open_amount) {
	this.total_open_amount = total_open_amount;
}
public String getBaseline_create_date() {
	return baseline_create_date;
}
public void setBaseline_create_date(String baseline_create_date) {
	this.baseline_create_date = baseline_create_date;
}
public String getCust_payment_terms() {
	return cust_payment_terms;
}
public void setCust_payment_terms(String cust_payment_terms) {
	this.cust_payment_terms = cust_payment_terms;
}
public String getInvoice_id() {
	return invoice_id;
}
public void setInvoice_id(String invoice_id) {
	this.invoice_id = invoice_id;
}
public String getIsOpen() {
	return isOpen;
}
public void setIsOpen(String isOpen) {
	this.isOpen = isOpen;
}
public String getPredicted() {
	return predicted;
}
public void setPredicted(String predicted) {
	this.predicted = predicted;
}
public String getIs_deleted() {
	return is_deleted;
}
public void setIs_deleted(String is_deleted) {
	this.is_deleted = is_deleted;
}
public String getBussiness_name() {
	return bussiness_name;
}
public void setBussiness_name(String bussiness_name) {
	this.bussiness_name = bussiness_name;
}
public String getName_customer() {
	return name_customer;
}
public void setName_customer(String name_customer) {
	this.name_customer = name_customer;
}
public String getCustNumber() {
	return custNumber;
}
public void setCustNumber(String custNumber) {
	this.custNumber = custNumber;
}
	
}



