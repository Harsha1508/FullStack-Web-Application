package com.servlets.HRC;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.crud.HRC.Crud;
import com.pojo.HRC.CustomersPojo;

public class Display extends Crud {
		
	public ArrayList<CustomersPojo> getData()
	{
		ArrayList<CustomersPojo> ALLStudents =new ArrayList<CustomersPojo>();//		
		
		try {
		 Connection conn = getConnection();
		 String sql_query="SELECT * from winter_internship";
		 PreparedStatement pst = conn.prepareStatement(sql_query);
		 ResultSet rs = pst.executeQuery();
		
		 while(rs.next())
		 {
			 CustomersPojo inv = new CustomersPojo();
			 					
				inv.setSl_no(rs.getInt("sl_no"));
				inv.setbCode(rs.getString("business_code"));
				inv.setCustNumber(rs.getString("cust_number"));
				inv.setClear_date(rs.getString("clear_date"));
				inv.setBussinessyear(rs.getString("buisness_year"));
				inv.setDocid(rs.getString("doc_id"));
				inv.setPostingdate(rs.getString("posting_date"));
				inv.setDocumentcreatedate(rs.getString("document_create_date"));
				inv.setDue_in_date(rs.getString("due_in_date"));
				inv.setInvoice_currency(rs.getString("invoice_currency"));
				inv.setDocument_type(rs.getString("document_type"));
				inv.setPosting_id(rs.getString("posting_id"));
				inv.setArea_business(rs.getString("area_business"));
				inv.setTotal_open_amount(rs.getString("total_open_amount"));
				inv.setBaseline_create_date(rs.getString("baseline_create_date"));
				inv.setCust_payment_terms(rs.getString("cust_payment_terms"));
				inv.setInvoice_id(rs.getString("invoice_id"));
				ALLStudents.add(inv);
				
				
		 }
		 
		 for(CustomersPojo stud: ALLStudents)
		 {
			 System.out.println(stud.toString());
		 }
		 
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception occur");
		}
		
		return ALLStudents;
		
	
	}

}

