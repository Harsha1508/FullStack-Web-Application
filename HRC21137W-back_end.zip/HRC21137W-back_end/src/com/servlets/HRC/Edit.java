package com.servlets.HRC;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.HRC.Crud;
import com.google.gson.Gson;


@WebServlet("/Edit")
public class Edit extends HttpServlet {
	private static final long serialVersionUID = 1L;       

    public Edit() {
        super();
    
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			String id =  request.getParameter("sl_no");
			String cpt = request.getParameter("cpt");
			String ic = request.getParameter("invoice");
			
		Crud con=new Crud();
		Connection conn = con.getConnection();
	     String query = "UPDATE winter_internship SET invoice_currency='"+ic+"', cust_payment_terms ='"+cpt+"' WHERE sl_no ="+id+";" ;
		PreparedStatement st = conn.prepareStatement(query);
		
		HashMap<Object,Object> response1= new HashMap<Object,Object>();
		if(st.executeUpdate()>0) {
			response1.put("insert",true);
		}
		else {
			response1.put("insert",false);
		}
		
		Gson gson=new Gson();
		String gson1=gson.toJson(response1);
		response.getWriter().print(gson1);
		response.setHeader("Access-Control-Allow-Origin","*");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		catch (Exception e) {
		
			e.printStackTrace();
		}

		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
