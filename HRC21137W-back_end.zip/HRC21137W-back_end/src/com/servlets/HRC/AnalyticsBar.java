package com.servlets.HRC;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.crud.HRC.Crud;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pojo.HRC.AnalyticBarPojo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AnalyticsBar")
public class AnalyticsBar extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AnalyticsBar() {
        super();
    }


protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		
		ArrayList<AnalyticBarPojo> Allcount =new ArrayList<AnalyticBarPojo>();
			try {
				String clear_date_start =  request.getParameter("clear_date_start");
				String due_date_start=request.getParameter("due_date_start");
				String clear_date_end =  request.getParameter("clear_date_end");
				String due_date_end = request.getParameter("due_date_end");
				String baseline_start= request.getParameter("baseline_start");
				String baseline_end = request.getParameter("baseline_end");


				Crud con=new Crud();
				Connection conn = con.getConnection();
			     String query = "SELECT business_code,COUNT(cust_number)AS total_customers,SUM(total_open_amount)AS total_amount "
			     		+ "FROM winter_internship WHERE clear_date>='"+clear_date_start+"' AND clear_date<='"+clear_date_end+"' AND due_in_date >='"+due_date_start+"' AND due_in_date<='"+due_date_end+"' AND baseline_create_date >='"+baseline_start+"' AND baseline_create_date<='"+baseline_end+"' AND invoice_currency ='USD' GROUP BY business_code";
					PreparedStatement st = conn.prepareStatement(query);
			
					 ResultSet rs = st.executeQuery();
					
					 while(rs.next()) {
						 AnalyticBarPojo inv = new AnalyticBarPojo();
						 
						 inv.setBusinessCode(rs.getString("business_code"));
						 inv.setTotalCustomers(rs.getString("total_customers"));
						 inv.setTotalAmount(rs.getString("total_amount"));
							Allcount.add(inv);
					 }
					 for(AnalyticBarPojo stud: Allcount)
					 {
						 System.out.println(stud.toString());
					 }
					 
					
				Gson gson = new GsonBuilder().serializeNulls().create();
				String invoices  = gson.toJson(Allcount);
				response.setHeader("Access-Control-Allow-Origin","*");
				response.setContentType("application/json");
				try {
					response.getWriter().write(invoices);
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
				rs.close();
				
				conn.close();
				
			}
			catch(SQLException e) {
				e.printStackTrace();
			}


					
	}}

