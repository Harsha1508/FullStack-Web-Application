package com.servlets.HRC;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.HRC.Crud;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.pojo.HRC.CustomersPojo;



@WebServlet("/AdvanceSearch")
public class AdvanceSearch extends HttpServlet  {
	private static final long serialVersionUID = 1L;
       

public AdvanceSearch() {
        super();

    }

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<CustomersPojo> ALLStudents =new ArrayList<CustomersPojo>();
		try {
			String doc_id =  request.getParameter("doc_id");
			String invoice_id = request.getParameter("invoice_id");
			String cust_number = request.getParameter("cust_number");
			String buisness_year = request.getParameter("buisness_year");
			
			
			Crud con=new Crud();
			 Connection conn = con.getConnection();
			 String sql_query="SELECT * from winter_internship where doc_id='"+doc_id+"' and invoice_id='"+invoice_id+"' and cust_number ='"+cust_number+"' and buisness_year ='"+buisness_year+"' ";
			 PreparedStatement pst = conn.prepareStatement(sql_query);
			 
			 ResultSet rs = pst.executeQuery();
			
			 while(rs.next())
			 {
				 CustomersPojo inv = new CustomersPojo();
					
					inv.setSl_no(rs.getInt("sl_no"));
					inv.setbCode(rs.getString("business_code"));
					inv.setCustNumber(rs.getString("cust_number"));	
					inv.setClear_date(rs.getString("clear_date"));
					inv.setBussinessyear(rs.getString("buisness_year"));
					inv.setDocid(rs.getString("doc_id"));
					inv.setPostingdate(rs.getString("posting_date"));
					inv.setDocumentcreatedate(rs.getString("document_create_date"));
					inv.setDocumentcreatedate1(rs.getString("document_create_date1"));
					inv.setDue_in_date(rs.getString("due_in_date"));
					inv.setInvoice_currency(rs.getString("invoice_currency"));
					inv.setDocument_type(rs.getString("document_type"));
					inv.setPosting_id(rs.getString("posting_id"));
					inv.setArea_business(rs.getString("area_business"));
					inv.setTotal_open_amount(rs.getString("total_open_amount"));
					inv.setBaseline_create_date(rs.getString("baseline_create_date"));
					inv.setCust_payment_terms(rs.getString("cust_payment_terms"));
					inv.setInvoice_id(rs.getString("invoice_id"));
					inv.setIsOpen(rs.getString("isOpen"));
					inv.setPredicted(rs.getString("aging_bucket"));
					inv.setIs_deleted(rs.getString("is_deleted"));
					ALLStudents.add(inv);
					
					
			 }
			 
			 for(CustomersPojo stud: ALLStudents)
			 {
				 System.out.println(stud.toString());
			 }
			 
			
		Gson gson = new GsonBuilder().serializeNulls().create();
		String invoices  = gson.toJson(ALLStudents);
		response.setHeader("Access-Control-Allow-Origin","*");
		response.setContentType("application/json");
		try {
			response.getWriter().write(invoices);//getWriter() returns a PrintWriter object that can send character text to the client. 
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		rs.close();
		
		conn.close();
		
	}
	catch(SQLException e) {
		e.printStackTrace();
	}		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}



