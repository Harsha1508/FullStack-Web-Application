package com.servlets.HRC;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;

import com.crud.HRC.Crud;
import com.google.gson.Gson;
import com.pojo.HRC.CustomersPojo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Add")
public class Add extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Add() {
        super();

    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());

			try {
				String bCode =  request.getParameter("buss_code");
				String custNumber=request.getParameter("cust_num");
				String clearDate =  request.getParameter("clear_date");
				String bussinessyear = request.getParameter("buss_year");
				String docid= request.getParameter("doc_id");
				String postingdate = request.getParameter("pos_date");
				String documentcreatedate = request.getParameter("d_date");
				String dueindate = request.getParameter("due_date");
				String invoicecurrency = request.getParameter("invoice");
				String documenttype = request.getParameter("doc_type");
				String postingid = request.getParameter("pos_id");
				String totalopenamount = request.getParameter("total");
				String baselinecreatedate = request.getParameter("bc_date");
				String custpaymentterms = request.getParameter("cpt");
				String invoiceid = request.getParameter("invoice_id");
				System.out.println("INV DET"+ custNumber + "-" + invoiceid );
			CustomersPojo newData = new CustomersPojo();
                newData.setbCode(bCode);
				newData.setCustNumber(custNumber);
				newData.setClear_date(clearDate);
				newData.setBussinessyear(bussinessyear);
				newData.setDocid(docid);
				newData.setPostingdate(postingdate);
			    newData.setDocumentcreatedate(documentcreatedate);
				newData.setDue_in_date(dueindate);
				newData.setInvoice_currency(invoicecurrency);
				newData.setDocument_type(documenttype);
				newData.setPosting_id(postingid);
				newData.setTotal_open_amount(totalopenamount);
     			 newData.setInvoice_id(invoiceid);
     			 newData.setBaseline_create_date(baselinecreatedate);
				newData.setCust_payment_terms(custpaymentterms);
				Crud con=new Crud();
				Connection conn = con.getConnection();
			     String query = "INSERT INTO winter_internship(business_code,cust_number,clear_date,buisness_year,doc_id,posting_date,document_create_date,due_in_date,invoice_currency,document_type,posting_id,total_open_amount,baseline_create_date,cust_payment_terms,invoice_id)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" ;
					PreparedStatement st = conn.prepareStatement(query);
					st.setString(1, bCode);
					st.setString(2, custNumber);
					st.setString(3, clearDate);
					st.setString(4, bussinessyear);
					st.setString(5,  docid);
					st.setString(6, postingdate);
					st.setString(7, documentcreatedate);
					st.setString(8, dueindate);
					st.setString(9, invoicecurrency);
					st.setString(10,  documenttype);
					st.setString(11, postingid);
					st.setString(12, totalopenamount);
					st.setString(13,  baselinecreatedate);
					st.setString(14, custpaymentterms);
					st.setString(15, invoiceid);
					HashMap<Object,Object> response1= new HashMap<Object,Object>();
					if(st.executeUpdate()>0) {
						response1.put("insert",true);
					}
					else {
						response1.put("insert",false);
					}
					
					Gson gson=new Gson();
					String gson1=gson.toJson(response1);
					response.getWriter().print(gson1);
					response.setHeader("Access-Control-Allow-Origin","*");
					response.getWriter().append("Served at: ").append(request.getContextPath());

					
					
			
			} catch (Exception e) {

				e.printStackTrace();
			}
			}
		

}
