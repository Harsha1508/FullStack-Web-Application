package com.servlets.HRC;

import java.io.IOException;
import java.sql.Statement;
import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.HRC.Crud;
import com.google.gson.Gson;

@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Delete() {
        super();
 
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			String id = request.getParameter("sl_no");
			System.out.println(id);
			String[] array = id.split(",");
			
		Crud con=new Crud();
		Connection conn = con.getConnection();
		Statement st=conn.createStatement(); 
		for(int i=0;i<array.length;i++)
		{
      		String queryy="DELETE FROM winter_internship where sl_no="+array[i]+"";
            st.executeUpdate(queryy);
			System.out.println(array[i] +" Deleted");
		}
		HashMap<Object,Object> response1= new HashMap<Object,Object>();
		
		
		Gson gson=new Gson();
		String gson1=gson.toJson(response1);
		response.getWriter().print(gson1);
		response.setHeader("Access-Control-Allow-Origin","*");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}